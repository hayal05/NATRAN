---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

## What happened?

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Environment
- NATRA version:
- Windows version:

## Logs/screenshots
